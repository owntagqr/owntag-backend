package com.qr_vehicle.QRvehicle.util;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.layout.Canvas;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.properties.TextAlignment;

import java.io.ByteArrayOutputStream;

public class StickerPdfRenderer {

    private static float cm(float cm) {
        return cm * 28.3465f;
    }

    public static void drawSticker(
            PdfCanvas pdfCanvas,
            Rectangle area,
            String uniqueCode,
            String tagId,
            String sheetCode
    ) throws Exception {

        Canvas canvas = new Canvas(pdfCanvas, area);

        // White background
        pdfCanvas.saveState();
        pdfCanvas.setFillColor(ColorConstants.WHITE);
        pdfCanvas.rectangle(
                area.getLeft(),
                area.getBottom(),
                area.getWidth(),
                area.getHeight());
        pdfCanvas.fill();
        pdfCanvas.restoreState();

        // Border
        pdfCanvas.roundRectangle(
                area.getLeft() + 2,
                area.getBottom() + 2,
                area.getWidth() - 4,
                area.getHeight() - 4,
                8);
        pdfCanvas.stroke();

        // QR URL
        String qrUrl = "https://owntag.in/v/" + uniqueCode;

        QRCodeWriter writer = new QRCodeWriter();

        BitMatrix matrix = writer.encode(
                qrUrl,
                BarcodeFormat.QR_CODE,
                300,
                300);

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        MatrixToImageWriter.writeToStream(matrix, "PNG", out);

        Image qr = new Image(ImageDataFactory.create(out.toByteArray()));

        qr.scaleAbsolute(cm(2.8f), cm(2.8f));

        qr.setFixedPosition(
                area.getLeft() + area.getWidth() - cm(3.3f),
                area.getBottom() + cm(1.2f));

        canvas.add(qr);

        canvas.showTextAligned(
                new Paragraph("owntag.in")
                        .setBold()
                        .setFontSize(11),
                area.getLeft() + area.getWidth() - cm(1.9f),
                area.getBottom() + cm(0.8f),
                TextAlignment.CENTER);

        canvas.showTextAligned(
                new Paragraph(tagId)
                        .setFontSize(9),
                area.getLeft() + area.getWidth() - cm(1.9f),
                area.getBottom() + cm(0.35f),
                TextAlignment.CENTER);

        canvas.showTextAligned(
                new Paragraph(sheetCode)
                        .setFontSize(8),
                area.getLeft() + cm(0.6f),
                area.getBottom() + cm(0.35f),
                TextAlignment.LEFT);

        canvas.close();
    }
}